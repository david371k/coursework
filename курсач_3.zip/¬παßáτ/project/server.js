require('dotenv').config(); // Load environment variables

const express = require('express');
const { Pool } = require('pg'); // Import the PostgreSQL pool
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = process.env.PORT || 3000;


// PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL, // Get from env variable
  ssl: {
    rejectUnauthorized: false, //For self-signed certs, remove in prod
  },
});



// Middleware
app.use(bodyParser.json());
app.use(cors());


// Example Authentication Middleware (using JWT)
const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const token = authHeader.split(' ')[1];
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = decoded;
      next();
    } catch (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
  } else {
    return res.status(401).json({ error: 'Authentication token required' });
  }
};



// API Routes (examples):

app.get('/api/users', authenticateJWT, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM users');
    res.json(rows);
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).json({ error: 'Failed to retrieve users.' });
  }
});

app.post('/api/users', async (req, res) => {
    // ... (POST request to create a new user) ...
});


app.post('/api/login', async (req, res) => {
  // ... (Login logic using PostgreSQL query) ...
});



// 1. Authentication (Login)
app.post('/api/login', async (req, res) => {
  // ... (Login logic as shown in the previous example) ...
});

// 2. User Data (Dashboard)
const User = require('./models/User');

// ... (other routes) ...

// GET all users
app.get('/api/users', async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (error) {
        console.error("Error fetching users:", error);
        res.status(500).json({ error: "Failed to retrieve users." });
    }
});

// POST a new user
app.post('/api/users', async (req, res) => {
    const newUser = new User(req.body);
    try {
        const savedUser = await newUser.save();
        res.status(201).json(savedUser); // 201 for successful creation
    } catch (error) {
        console.error("Error creating user:", error);
        if (error.code === 11000) {
            // Duplicate key error (e.g., unique constraint violation)
            return res.status(400).json({ error: 'Username or email already exists.' });
        }
        res.status(500).json({ error: "Failed to create user." });
    }
});


// 3. Loan Data (Dashboard)
app.get('/api/loans', authenticateJWT, async (req, res) => {
  try {
    const loans = await Loan.find({ userId: req.user.userId });
    res.json(loans);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch loan data' });
  }
});


// 4. Create Loan Request
app.post('/api/loans', authenticateJWT, async (req, res) => {
  try {
    const newLoan = new Loan({ ...req.body, userId: req.user.userId });
    await newLoan.save();
    res.status(201).json({ message: "Loan request created successfully!" });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create loan request' });
  }
});


// 5. Events (Homepage and Events Page)
app.get('/api/events', async (req, res) => {
  try {
    const events = await Event.find();
    res.json(events);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});


// 6. Profile Update
app.put('/api/profile', authenticateJWT, async (req, res) => {
  try {
    const updatedUser = await User.findByIdAndUpdate(req.user.userId, req.body, { new: true });
    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update profile' });
  }
});


//Start the server
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});