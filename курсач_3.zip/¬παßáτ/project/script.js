const apiBaseUrl = 'http://localhost:3000/api'; 

// Логин
const loginForm = document.getElementById('loginForm');

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const formData = new FormData(loginForm);
  const data = Object.fromEntries(formData);

  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
        if (response.status === 401) {
            alert("Incorrect username or password");
            return; // Stop further execution if login fails
        } else {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
    }

    const { token } = await response.json();
    localStorage.setItem('token', token); // Store token (securely in production)

    window.location.href = '/dashboard.html'; // Redirect to dashboard

  } catch (error) {
    console.error('Login error:', error);
    alert('Login failed. Please check your credentials.');
  }
});

// Пользователь
document.addEventListener('DOMContentLoaded', async () => {
  const featuredEventsSection = document.getElementById('featuredEvents'); // Assumes you have a div with this ID

  try {
    const response = await fetch('/api/featuredEvents');
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const events = await response.json();

    // Dynamically create event cards
    const eventCardsHTML = events.map(event => `
      <div class="event-card">
        <h3>${event.title}</h3>
        <p>${event.description.substring(0, 100)}...</p>  <!-- Truncate description -->
        <p>Date: ${event.date.toDateString()}</p>
        <p>Time: ${event.time}</p>
        <a href="/events.html" class="btn btn-primary">View Event</a>
      </div>
    `).join('');

    featuredEventsSection.innerHTML = eventCardsHTML;

  } catch (error) {
    console.error('Error fetching events:', error);
    featuredEventsSection.innerHTML = '<p>Error loading events.</p>';
  }
});
// Проф.
document.addEventListener('DOMContentLoaded', async () => {
  //Get user data and populate form
});

const profileForm = document.getElementById('profileForm');
profileForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  // Submit updated profile data using fetch.
});

// кредит
document.addEventListener('DOMContentLoaded', async () => {
  //Fetch loan details, populate form
});

const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener('submit', async (event) => {
event.preventDefault();
//Submit payment data using fetch
});

// информ
document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem('token');
  if (!token) {
      window.location.href = '/login.html'; // Redirect to login if no token
      return;
  }

  const loanTable = document.getElementById('loan-table');
  const eventsSection = document.getElementById('upcomingEvents'); // Assumes you have a div with this ID.

  try {
    const response = await fetch('/api/user', {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) {
      if (response.status === 401) {
        localStorage.removeItem('token'); // Remove token and redirect
        window.location.href = '/login.html';
        return;
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const userData = await response.json();
    document.getElementById('userName').textContent = userData.username; //Example


    const loansResponse = await fetch('/api/loans', {
        headers: { Authorization: `Bearer ${token}` },
    });

    if (!loansResponse.ok) {
        throw new Error(`HTTP error! status: ${loansResponse.status}`);
    }

    const loans = await loansResponse.json();
    // Update the loan table dynamically using loans data
    populateLoanTable(loans);



    const eventsResponse = await fetch('/api/events'); //Get events, no auth needed here.
    const events = await eventsResponse.json();
    // Update your HTML to display events (e.g., using innerHTML)
    const eventHTML = events.map(event => `<h3>${event.title}</h3><p>${event.description}</p>`).join('');
    eventsSection.innerHTML = eventHTML;


  } catch (error) {
    console.error('Error fetching data:', error);
    alert('An error occurred. Please try again later.');
  }
});


function populateLoanTable(loanData) {
  const tableBody = document.querySelector('#loan-table tbody');
  tableBody.innerHTML = ''; //Clear existing rows
  loanData.forEach(loan => {
    // Create table rows for the loans.
  });
}