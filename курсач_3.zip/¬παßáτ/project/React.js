import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);


// App.js (main application component)
import React, { useState, useEffect } from 'react';
import './App.css';
import Login from './Login';
import Dashboard from './Dashboard';

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(null);

  useEffect(() => {
    const checkToken = async () => {
      if (token) {
        try {
          const response = await fetch('/api/user', {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (response.ok) {
            const userData = await response.json();
            setUser(userData);
          } else if (response.status === 401) {
            // Token invalid or expired, clear it and redirect
            localStorage.removeItem('token');
            window.location.href = '/login'; // Adjust for your login page route
          } else {
            console.error('Error fetching user data', response);
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
          // Handle error, e.g., redirect to login
        }
      }
    };
    checkToken();
  }, [token]); // This useEffect runs when token changes

  return (
    <div className="App">
      {user ? (
        <Dashboard user={user} />
      ) : (
        <Login setToken={setToken} />
      )}
    </div>
  );
}
export default App;



// Login.js
import React, { useState } from 'react';

function Login({ setToken }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      if (response.ok) {
        const { token } = await response.json();
        setToken(token);
        localStorage.setItem('token', token);
        // Redirect to dashboard, handling any potential errors during redirection.
        window.location.href = '/dashboard'; // Redirect to Dashboard
      } else {
        console.error('Login failed', response);
        // Display a more user-friendly error message
        alert('Invalid username or password');
      }
    } catch (error) {
      console.error('Login error:', error);
      // Handle errors like network issues
      alert('Login failed. Please check your connection.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* ... your login form elements ... */}
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button type="submit">Login</button>
    </form>
  );
}

export default Login;
